<?php
 $categorias = array(
    "Juegos" => array(
       'Carrera', 
       'Pelea', 
        'Guerra', 
           ),
    "Ropa" => array(
       'Camisas' => 'Camisas',
       'Pantalones' => 'Pantalones', 
       'Vestidos' => 'Vestidos', 
      
    ),
    "Electrodomesticos" => array(
       'Televisores' => 'Televisores',
       'Lavadoras' => 'Lavadoras',
       'Computadoras' => 'Computadoras',
     
    )
 );

?>